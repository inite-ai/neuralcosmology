# `@inite/mcp`

MCP (Model Context Protocol) server transport for `@inite/*` verticals. Bridges the existing `@inite/assistant` `ToolModule` registry to MCP so external clients (Claude Desktop, Cursor, Goose, ChatGPT, n8n) can call vertical tools directly. Per **ADR-003**.

## Install

```bash
pnpm add @inite/mcp@workspace:*
```

Peer dep: `zod ^3.25 || ^4`.

## The tenant door: `createMcpRoute`

One company's tools from `@inite/assistant`, for its staff's agents, at `/mcp/{companySlug}`. It runs on the core's own route, like every site door, so refusals are RFC 9457 problems and every answer carries RateLimit headers.

```ts
// src/app/mcp/[companySlug]/route.ts
import { createMcpRoute } from "@inite/mcp/server";

export const door = createMcpRoute({
  toolModes: ["backoffice"],
  serverInfo: { name: "inite-rent", title: "INITE Rent", version: "2.0.0" }, // the surface's semver
  scopes: { read: "rent:read", write: "rent:write", purchase: "rent:purchase", purchaseTools: ["charge_deposit"] },
  permissions: CAR_RENTAL_TOOL_PERMISSIONS,          // strict: an unmapped tool is not served
  site: "https://inite.rent",
  authenticate: async ({ token, companySlug, audiences }) => {
    // A JWT (verify with `audience: audiences`) or an API key the product looks up.
    // Return the member's role and the company's overrides, and the scopes the credential carries.
    return { toolCtx, role, overrides, scopes };
  },
});
export const { POST, GET, OPTIONS } = door;
// app/.well-known/oauth-protected-resource/mcp/[companySlug]/route.ts: export const GET = door.metadata;
// app/mcp/route.ts: export const POST = door.root;   (points at /mcp/{companySlug})
```

What the door enforces (owner decisions of 09.11.2026):
- **Bearer only.** The authenticator never sees a cookie.
- **Exact audience.** A JWT must name `<site>/mcp/<slug>`; nothing else, not the `/mcp` root, not a client id.
- **Product scopes.** A credential with neither `:read` nor `:write` gets 403 `insufficient_scope`. A write tool needs `:write`, and a `purchaseTools` entry needs `:purchase`. An API key's authenticator says which scopes the key carries.
- **Permissions as the app sees them:** the `role` plus the company's `overrides`, then the map. `strictPermissions: false` is the opt-out.
- **An authenticator that throws gets 503**, not a 401 carrying its message.
- **Tools as the site doors publish them:**
  - the hints from `ToolMeta.annotations[name]` (guessed from the name only when nothing is declared);
  - the tool's zod `outputSchema`;
  - `{ error }` / `{ ok: false }` answers as `isError`;
  - `ToolMeta.uiBundle` as the card when `apps` serves it.
- **Surface record:** `door.surface(auth)` gives the product's test what to pass to `surfaceFingerprint` and `checkSurfaceVersion`.

Removed on 09.11.2026: `loginUrl` (the 401 no longer advertises `@inite/cli`), `resourceMetadataUrl` (the document is served by `metadata`), `audiences` and the shared root audience, and `appsEnabled` (use `apps`).

## A yes the model cannot give: `turn.consent`

Every charge, outbound message, booking and delete asks the person through a channel whose answer the model never holds (owner decision 3, 09.11.2026). This applies even when a wallet allowance would cover the amount. `confirm: true` is not enough: the model writes that argument itself.

```ts
{
  name: "buy_book",
  inputSchema: withConsent({ type: "object", properties: { book: { type: "string" } }, required: ["book"] }),
  ui: confirmApp(SITE),
  async call(args, ctx, turn) {
    const yes = await turn.consent("pay", { message: `Pay R$ 49 for ${args.book}?`, summary: { Price: "R$ 49" } });
    if (yes.status === "pending") return yes.result;
    if (yes.status === "declined") return textResult("Not bought.");
    return pay(args, { consent: yes.proof });       // @inite/billing payFromWallet refuses without it
  },
}
```

The channels, in order:
1. **The client's own form.** A modern client that elicits shows the form. The answer is bound to the signed `requestState`.
2. **The card.** For a client that renders MCP Apps, the token sits in the result's `_meta` (`ai.inite/consent`). The model is never shown it. The card's Confirm button (`INITE.confirm`) sends it back.
3. **A code.** `consent.deliver` sends six digits to the person's own address. The model gets a reference and must ask the person for the digits.
4. **Refusal.** If none of these is available, the action is refused, with `consent.finishUrl`.

Every token binds the tool, a hash of the arguments, the caller and an expiry. Each is single-use (`consent.store`; the default is in memory, so pass a shared store when you run several replicas).

**App-only tools** (`ui: { app, visibility: ["app"] }`) answer only their card. Every result shown with a card carries a card token in `_meta` (`ai.inite/card`). The runtime sends it back as `_card`; a direct call from the model is a tool error.

## Node frameworks: `@inite/mcp/node`

Every route builder here returns Fetch handlers (`{ POST, GET, OPTIONS }`). Next.js and Hono mount them as they are; Express and Nest go through the adapter, which carries the whole request across: every header as sent (so `Mcp-Method`, `Mcp-Name` and `MCP-Protocol-Version` reach the core), the raw body (Nest `rawBody: true`, or the parsed JSON re-encoded), and the public URL from Host.

```ts
import { nodeHandler, sendFetch, honoHandler } from "@inite/mcp/node";

app.all("/mcp", nodeHandler(door));                        // Express
@All("mcp") mcp(@Req() req, @Res() res) { return sendFetch(door, req, res); }   // Nest
app.all("/mcp", honoHandler(door));                        // Hono
```

Do not write a header allow-list in front of the core: Break3's dropped `Mcp-Method`, and every 2026-07-28 request was refused with -32020.

`@inite/mcp`, `@inite/auth` and `@inite/problem` also ship a CommonJS build (`require` resolves to `dist/cjs/`), for Nest apps and Jest. `@inite/mcp/server` (tenant doors) still needs a bundler, because `@inite/assistant` does.

## The family door registry: `@inite/mcp/registry`

Every MCP door of every product is listed once, in `src/registry/doors.ts`. Each entry has its product, kind (public, tenant, storefront or operator), URL, sign-in, scopes, status and repo. A new door is added there in the PR that builds it.

These are generated from the registry:
- `authRegistry()`: what INITE Auth needs, namely the family domains, each door's resource pattern with its scopes, and the scopes' descriptions. `doorForResource(url)` is the check for a connector's `resource`.
- `serverCard(site)` / `serverCardResponse(site)`: `/.well-known/mcp/server-card.json`.
- `llmsSection(site)`: the "## MCP" section of the site's llms.txt.
- `registryServer(door, version)`: the official MCP registry's `server.json`.

Public, tenant and storefront doors are listed once they are live. An operator door is never listed, and the test refuses one that is marked listed. A company slug of `operator` or `s` is reserved, because those paths are the operator and storefront doors.

## Storefront doors: `@inite/mcp/storefront`

`createStorefrontMcp` serves one business's store to its customers' agents at `/mcp/s/{storeSlug}` (owner decision 4).
- **Browsing is open.**
- **Customer sign-in is optional and scoped to the store.** `customerTools` answer a guest with the sign-in 401 for that exact URL and the `<product>:customer` scope. `authenticateCustomer` checks that the token is a customer of this store.
- **Tools come from the assistant's `booking` mode.** They are bridged like the tenant door's tools.
- **Every write** (order, booking, cancellation) **asks the person** through `turn.consent`.
- **Cards:** catalog, order, slots and confirm (`storefrontApps(site)`).
- **A closed or unknown store** answers 404.
- **A customer sees only their own records.** `customerOf(ctx)` is the signed-in customer (`{ companyId, customerId }`) or null for a guest; a customer tool scopes every query by both. `verifiedEmailCustomer({ verify, find })` is the `authenticateCustomer` for a store that knows its customers by email: a verified INITE email that this store holds. First live door on it: INITE Health's patient door (`/mcp/s/{clinicSlug}`, 18.11.2026).
- **Booking cards in the kit:** `SlotPickerCard` (free times, each a button that books; the consent and the result come back into the card) and `MyBookingsCard` (the customer's own upcoming and past bookings or orders, upcoming ones cancellable). Data contracts in `apps/kit/booking.tsx`; a product's widget is `mount(SlotPickerCard)`.

## Operator doors: `@inite/mcp/operator`

`createOperatorMcp` is docs/OPERATOR-MCP.md as code:
- a token minted for this door only, with an operator role (`superadmin` or `<product>:operator`) on every call;
- browser pages refused, and a cap on the batch;
- one `audit` entry per call, refused calls included, with the arguments as `auditArgs` keeps them;
- `twoStep()` for anything that leaves the system: a hashed single-use code, 30 minutes, five tries, and the stored payload sent byte for byte.

The registry marks it `kind: "operator"`, so it is never listed.

## Widget kit v2: `@inite/mcp/apps/kit` (Preact)

Owner decision 8: widgets are Preact plus one shared component kit. The kit gives you:
- `mount(App)` and `useHost()`, which hands you the data, the error, `call` and the locale;
- components: `List`, `Card`, `Table`, `Receipt`, `Slots`, `BarChart`, `ConfirmForm` (for `turn.consent`), `ToolButton`, and the `Frame`, `Empty`, `ErrorBox` and `Loading` states;
- the storefront's booking cards: `SlotPicker`/`SlotPickerCard`, `MyBookings`/`MyBookingsCard`, `BookingAnswer`, words in en, es, pt, ru (`bookingWords`);
- INITE tokens, light and dark.

Build with `buildApps({ preact: true })`:
- JSX goes to Preact, and `react` / `react-dom` imports go to `preact/compat`;
- a widget page over `maxBytes` (60 KB by default with Preact) fails the build;
- the test fixture comes to about 21 KB (9 KB gzipped). A Break3 widget is about 290 KB.

What the runtime now guarantees in both hosts:
- `callTool` redraws the card from the answer and throws on `isError`; ChatGPT did neither before 09.11.2026;
- the height is reported after every render, so the card never sits at height 0;
- messages are taken from the parent frame only;
- the card's token is sent for app-only tools.

`domain` (`buildApps({ domain })` or `SiteApp.domain`) publishes `_meta.ui.domain` and `openai/widgetDomain`. ChatGPT requires them when an app is submitted.

## The same card in Telegram: `@inite/mcp/telegram`

Bot API 10.4 (09.11.2026) puts HTML widgets into chat messages. A card made
with `app()` keeps its script, and `telegramWidget(card)` runs it on a small
`TelegramWidget` shim instead of the MCP Apps runtime, which does not fit
Telegram's 4 KB compressed limit. The shipped cards come to 1.6-2 KB.

```ts
import { plansApp } from "@inite/mcp/product";
import { telegramWidget, widgetData, sendWidget, editWidgetData, botCall } from "@inite/mcp/telegram";

const call = botCall(process.env.TELEGRAM_BOT_TOKEN!);
const w = telegramWidget(plansApp("inite")); // throws WidgetTooBig if Telegram would refuse it
const sent = await sendWidget(call, chatId, w, { chatData: widgetData({ currency: "USD", plans }) });
if (sent.ok) await editWidgetData(call, chatId, sent.messageId, widgetData({ currency: "USD", plans: next })); // redraws in place
```

- Data is `chat_data`: JSON within 1024 bytes (`widgetData` refuses more). Pass a compact form, not the whole structuredContent.
- `INITE.callTool(name, args)` becomes a widget query `[name, args]` (64 bytes at most). The bot reads it with `readWidgetQuery` and answers with `answerWidgetQuery`, and `sendWidget` needs `allowQueries: true`.
- `INITE.openLink`, `esc`, `theme`, `locale` and `onData` work. `confirm`, `sendMessage` and `updateModelContext` have no Telegram meaning: they resolve or refuse.
- On production Telegram takes widgets only in private chats with the bot, a topic of that chat included. Groups are on the test server so far.

## A site's own MCP server: `@inite/mcp/site`

For a public site (a shop, a blog, a portfolio) that wants AI agents to search it, read it and buy from it. No companies, no `@inite/assistant`, no dependencies.

Usually two endpoints:
- `/mcp`, open to any agent;
- `/mcp/account`, where the agent acts for a person who signed in with INITE. The agent's MCP client does the sign-in itself: it reads the 401, finds INITE Auth, registers and asks the person. The site needs no OAuth client of its own for this.

```ts
// lib/mcp.ts
import { createSiteMcp, protectedResource, jsonResult, textResult } from "@inite/mcp/site";
import { verifyAccessToken } from "@inite/auth";

const SITE = "https://www.example.com";
export const account = protectedResource({ site: SITE, path: "/mcp/account", name: "Example", documentation: `${SITE}/llms.txt` });

type Ctx = { reader: string | null };
export const mcp = createSiteMcp<Ctx>({
  name: "example",
  title: "Example",
  instructions: (ctx) => (ctx.reader ? "Signed in as the reader." : "Connect to /mcp/account to act for a reader."),
  tools: (ctx) => [
    {
      name: "search",
      description: "Search the site.",
      inputSchema: { type: "object", properties: { query: { type: "string" } }, required: ["query"] },
      annotations: { readOnlyHint: true },
      call: async ({ query }) => jsonResult({ results: await search(String(query)) }),
    },
  ],
});

// app/mcp/route.ts
export const { POST, GET, OPTIONS } = mcp.route({ context: () => ({ reader: null }) });

// app/mcp/account/route.ts
export const { POST, GET, OPTIONS } = mcp.route({
  resource: account,
  authenticate: (token, aud) => verifyAccessToken(token, { audience: aud }).catch(() => null),
  context: (_req, claims) => ({ reader: (claims as { sub: string }).sub }),
});

// app/.well-known/oauth-protected-resource/[[...path]]/route.ts
export const GET = protectedResourcesRoute([account]);

// app/.well-known/mcp.json/route.ts
export const GET = () => mcpCardResponse({ site: SITE, name: "example", title: "Example", description: "…",
  endpoints: [{ path: "/mcp" }, { path: "/mcp/account", resource: account }] });

// app/.well-known/mcp-registry-auth/route.ts  (to publish in the official MCP registry)
export const GET = () => mcpRegistryAuthResponse("<base64 ed25519 public key>");
```

A tool that throws becomes an error result the agent can read; the exception text stays in the log. `textResult(text, isError)` and `jsonResult(value)` build answers. For buying, pair it with `@inite/billing/purchases`: open a session, try `payFromWallet` for a signed-in reader, otherwise return `checkoutUrl` and `x402Url`.

### One endpoint, sign-in only where a tool needs it

Two endpoints mean an agent has to be connected twice. Instead, one `/mcp` can serve anonymous agents and act for a person in the same place: give the route `signIn: "optional"`, and mark the tools that act for a person `signedIn` (`true`, or `{ scope, when }`). Calling such a tool without a token answers HTTP 401 with `WWW-Authenticate: Bearer resource_metadata="…", scope="shop:purchase"`, so the client signs the person in exactly then; a token without the scope gets 403 `insufficient_scope`. A token that is sent is checked on every request, and a bad one is a 401 at once, even for a public tool.

```ts
const shop = protectedResource({ site: SITE, path: "/mcp", name: "Example", scopes: ["shop:purchase"] });

const mcp = createSiteMcp<Ctx>({
  name: "example",
  websiteUrl: SITE,
  onToolCall: ({ tool, outcome, ms }) => count(tool, outcome, ms), // never sees the arguments
  tools: [
    { name: "search", inputSchema, parse: (a) => SearchInput.safeParse(a), call: (args) => result(text, data) },
    { name: "buy", inputSchema, signedIn: { scope: "shop:purchase" }, call: (args, ctx) => buy(ctx.person) },
    // Only some calls need the person: book anonymously, or with their profile.
    { name: "book", inputSchema, signedIn: { scope: "shop:booking", when: (a) => a.useProfile === true }, call },
  ],
});

export const { POST, GET, OPTIONS } = mcp.route({
  resource: shop,
  signIn: "optional",
  authenticate: (token, aud) => verifyAgentToken(token, { audience: aud }), // @inite/auth/agent; has .scopes
  context: (req, person) => ({ person }),
  beforeRequest: (req) => rateLimit(clientIp(req)), // a Response refuses, null lets it through
  maxBodyBytes: 256 * 1024, // the default; 413 above it
  rateLimit: { limit: 60, windowSeconds: 60 }, // per client IP; RateLimit headers on every answer, 429 with exact Retry-After
});
```

Without `parse`, every call's arguments are checked against the tool's `inputSchema` (required, type, enum, minimum/maximum, length) and an argument the schema does not name is refused unless the schema says `additionalProperties: true`. The agent gets one error result listing everything wrong, e.g. `query must be a string, got number; unknown argument q (expected: query, locale, limit)`. `checkArguments: false` turns this off for a layer that validates on its own. `invalidResult: (tool, problem) => ToolResult` answers a refused call in the site's own shape; without it the text is exactly `Invalid arguments for <tool>: <problem>.` (inite.ai maps errors to codes by that beginning, so it stays). In the family's problem shape:

```ts
invalidResult: (tool, problem) => ({
  content: [{ type: "text", text: `Invalid arguments for ${tool}: ${problem}.` }],
  structuredContent: {
    error: { type: "https://inite.ai/problems/invalid-input", title: "Invalid input", status: 400, code: "invalid-input", detail: problem },
  },
  isError: true,
}),
```
 `params` that is not an object is `-32600`, `arguments` that is not an object `-32602`.

HTTP refusals (400 bad JSON, 405 GET, 413, 429) are `application/problem+json` (RFC 9457) and the same object is the JSON-RPC error, so plain HTTP clients and MCP clients both read them.

`parse` takes zod's `safeParse` as it is (or any `{ success, data | error }`); bad arguments come back to the agent as an error result that names the problem, and `call` gets the parsed values. `result(text, data)` answers with words for the person and the same facts as `structuredContent`. A scoped tool checks `scopes` on whatever `authenticate` returned (`verifyAgentToken` has them); an authenticator that reports no scopes is trusted as it is. Without `signIn: "optional"` a route with `resource` needs the person on every request, as before.

Working examples: neuralcosmology.com (`/mcp`, `/mcp/account`), mikefluff.com (`/mcp`, one endpoint), billing.inite.ai/mcp/wallet.

### Cards in the chat (MCP Apps, ChatGPT)

A tool's answer can show as a card instead of JSON, in every host that renders UI: Claude, ChatGPT, VS Code, M365 Copilot, Goose and the other MCP Apps hosts (`_meta.ui.resourceUri` → a `ui://` resource, `text/html;profile=mcp-app`). ChatGPT's aliases (`openai/outputTemplate`, `openai/widgetCSP`, `window.openai`) are set alongside. One runtime (`src/apps/runtime.ts`) speaks the standard `ui/*` bridge first and uses `window.openai` only for what ChatGPT alone has (widget state, its `callTool`). Clients without UI get the text answer, so always return both (`jsonResult` does). No product writes its own bridge or host adapter: they live here once.

Two ready cards for anything a site sells:

```ts
import { catalogApp, orderApp } from "@inite/mcp/site";

const catalog = catalogApp("mysite", ["https://www.mysite.com"]);   // image domains
const order = orderApp("mysite", ["https://www.mysite.com"]);

createSiteMcp({
  name: "mysite",
  apps: [catalog, order],
  tools: [
    { name: "list_books", ui: { app: catalog, invoking: "Looking…", invoked: "Books" },
      call: () => jsonResult({ items: [{ title, subtitle, image, price: "$15", url,
                                         action: { tool: "create_checkout", arguments: { item }, label: "Buy" } }] }) },
    { name: "create_checkout", ui: order,
      call: () => jsonResult({ title, image, price: "$15", status: "open", checkoutUrl, approveUrl, x402Url }) },
  ],
});
```

- **Catalog**: covers, prices, a Buy button that calls the tool you name, an Open button for the page.
- **Order**: what is bought and every way to pay. "Pay from INITE wallet" opens the approve page (passkey), "Pay by card or PIX" the payment page; paid/confirming shows as done.
- Your own small card: `app({ uri, name, css, script })` gets the same light/dark base and `INITE.onData(render)`, `INITE.openLink(url)`, `INITE.callTool(name, args)`, `INITE.esc(text)`.

### Widgets from a product's own components

A product builds its widgets from the components its app already has, so the card in the chat is the app's own UI, not a second drawing:

```ts
// the widget (bundled): src/mcp-apps/today.jsx
import { connect } from "@inite/mcp/apps/client";
const host = connect();
host.onData((data) => render(<Today data={data} onDone={(id) => host.callTool("check_in", { habit: id })} />));

// the product's build step (Node)
import { buildApps } from "@inite/mcp/apps/build";
await buildApps({ product: "break3", outDir: "build/mcp-apps", apps: { today: { entry: "src/mcp-apps/today.jsx" } } });
// → today.<hash>.html (JS and CSS inline, no network) + manifest.json

// the MCP server
import { loadApps, withApp, appOnly } from "@inite/mcp/apps";
const widgets = loadApps("https://break3.app/mcp-apps");   // once at start, refresh() on a new release
createSiteMcp({ apps: widgets.apps, tools: [withApp(listToday, () => widgets.byName("today"))] });
```

- `defineApp` names a widget by its content (`ui://<product>/<name>-<hash>.html`): a host never pairs a cached old widget with a new data contract.
- `withApp(tool, app, { visibility })` attaches it; `appOnly(tool, app)` is a button-only tool the model does not see (MCP Apps `visibility: ["app"]`, ChatGPT `openai/visibility: "private"` + `widgetAccessible`).
- The runtime: `onData`, `onInput`, `callTool`, `openLink`, `sendMessage` (posts into the chat), `updateModelContext`, `requestDisplayMode`, `getState`/`setState`, `theme`, `locale`, `esc`.
- `@inite/mcp/apps/harness` renders a widget in a pretend host, in MCP Apps mode and in ChatGPT mode, for Playwright tests (`pnpm test:apps`; `INITE_BROWSER_CHANNEL=chrome` uses an installed Chrome).

## Both MCP eras on one endpoint (2026-07-28)

`createSiteMcp` (and `createMcpRoute`, which runs on it) serves the stateless 2026-07-28 revision and the handshake-based ones side by side:

- a request with `params._meta["io.modelcontextprotocol/protocolVersion"]` is modern: `server/discover`, `resultType` on every result, `ttlMs`/`cacheScope` on lists and reads, the server's identity in `_meta`, `UnsupportedProtocolVersionError` (-32022) for an unknown version, `Mcp-Method`/`Mcp-Name` checked against the body (-32020);
- anything else is served as before (`initialize`, plain results).

**Asking the person mid-call** (multi round-trip requests): a tool calls `await turn.ask(key, { message, schema })`. A modern client that elicits gets `resultType: "input_required"` with a form and retries with the answer; the `requestState` is HMAC-signed and bound to the tool, its arguments and the caller (`stateSecret`, `principalOf`). A legacy client, or one without forms, gets a text answer telling the model to ask and call again with `confirm: true` (add the argument with `withConfirm(schema)`).

**Refusals** are tool errors in RFC 9457 shape: `problemResult({ code, title, status, detail }, "https://example.com/problems")` gives `isError: true` with `structuredContent.problem` (`type`, `title`, `status`, `code`, `detail`).

## MCP-AUDIT: what the core guarantees, and how a product keeps it

Problems are built by `@inite/problem` (no dependencies; `@inite/api-kit` uses the same builder), so `@inite/mcp/site` still pulls in no third-party code.

The core is checked against an eight-point audit (`CONFORMANCE.md`, `src/site/audit.test.ts`), so every product inherits the fixes instead of redoing them:

1. **Surface version.** `version` is the MCP surface's semver; the build goes in `buildId` (`_meta["ai.inite/build"]`). A product records `{ version, fingerprint }` and tests it:

   ```ts
   import { surfaceOf, surfaceFingerprint, checkSurfaceVersion, surfaceSize } from "@inite/mcp/site";
   const surface = await surfaceOf(server, ctx);
   expect(checkSurfaceVersion({ version: VERSION, fingerprint: await surfaceFingerprint(surface) }, record)).toEqual([]);
   expect(surfaceSize(surface).toolsTokens).toBeLessThan(BUDGET);
   ```
2. **Protocol versions.** An unknown `initialize` version gets the newest handshake version; an unknown modern version gets -32022 with the versions spoken.
3. **HTTP refusals.** 400/405/406/413/415/429 are `application/problem+json` (`problemResponse`, built on `@inite/problem`) and carry the JSON-RPC error in the same body; `problemBase` sets where `type` points. 401/403 are problems with OAuth's `error` (only after a failed token).
4. **Arguments.** Tools without their own `parse` are checked against `inputSchema` (SEP-1303): a tool error (text by default, the site's shape with `invalidResult`), never a protocol error or a silent pass.
5. **Params.** Non-object `params` is -32600.
6. **Rate limits.** `route({ rateLimit: { limit, windowSeconds, key? } })`: RateLimit and RateLimit-Policy on every answer, an exact Retry-After on 429; `rateWindow(...).take(key)` for a product's own counters (e.g. writes per person).
7. **Resource templates.** `resourceTemplates: [{ uriTemplate, name, signedIn?, read }]`, listed and read by URI.
9. **Request-metadata headers.** A 2026-07-28 request must carry `MCP-Protocol-Version`, `Mcp-Method` and (tools/call, resources/read, prompts/get) `Mcp-Name` matching its body (Base64 sentinel decoded); otherwise HTTP 400 with -32020. An unsupported version is 400 and an unknown modern method 404.
8. **Budgets.** `surfaceSize` for tools/list, and `outputProblems(outputSchema, structuredContent)` for read tools.

## Titles and behaviour hints

Every tool is published with a `title` and all four MCP hints (`readOnlyHint`, `destructiveHint`, `idempotentHint`, `openWorldHint`), on both `createMcpRoute` and `@inite/mcp/site`. App directories (ChatGPT, Claude) flag tools without them, and clients use them to decide when to ask the person first.

Whatever a tool declares is kept (`title`/`annotations` on a site tool; `title`/`annotations` on an `@inite/assistant` tool). The rest comes from the name: `get_/list_/search_/…` are read-only, `delete_/cancel_/revoke_/release_/…` are destructive, the title is the name made readable. Declare the hints when the name could mislead (`toolAnnotations` in `@inite/mcp` shows what will be published).

## Sub-paths

- `@inite/mcp/site` — the one server core: `createSiteMcp`, `result`, `problemResult`, `withConfirm`, `protectedResource`, `protectedResourcesRoute`, `mcpCard`, `mcpRegistryAuthResponse`
- `@inite/mcp/server` — `createMcpRoute` on that core; `bridgeTools`, and `FetchTransport` (deprecated, kept for content-generator's own McpServer)
- `@inite/mcp/apps` — `defineApp`, `withApp`, `appOnly`, `appsFromManifest`, `loadApps`; `buildToolResult` (deprecated)
- `@inite/mcp/apps/client`, `/apps/build`, `/apps/harness` — see "Widgets from a product's own components"
- `@inite/mcp/prompts` — `registerSkillsAsPrompts` (SDK servers), `skillPrompts` (the core)
- `@inite/mcp/telegram` — `telegramWidget`, `widgetData`, `sendWidget`, `editWidgetData`, `answerWidgetQuery`, `readWidgetQuery`: a card as a Telegram widget

## Design constraints

- Stateless: every POST stands alone, no session state (MCP 2026-07-28 is stateless too).
- Web `Request` / `Response` only — built for Next.js App Router route handlers, not Express.
- No domain knowledge. Tool permission map + auth callback come from the consumer.

## Related

- `ADR-003: MCP Server + Skills` — locked contract.
- `docs/OPERATOR-MCP.md` — the family standard for a product's operator (admin) door.
- `ADR-001: Composable UI Two-Path Envelope` — `buildToolResult` implements path 2 of this ADR.
- `@inite/assistant` — the tool registry this package bridges from.

## Audience, rate limit, scopes

Superseded on 09.11.2026 by the tenant door section above: the audience is the endpoint's URL only, the rate limit answers with RateLimit headers and a 429 problem, and the product's scopes are enforced per call. `@inite/cli proxy` 0.4.0+ binds its token to the remote it proxies (RFC 8707 `resource`), so it keeps working.

## A product sells itself: `@inite/mcp/product`

The product-public layer of the family MCP plan (§2b): the nine tools every
vertical answers anonymously at `https://inite.<vertical>/mcp`
(`what_it_does`, `plans_and_prices`, `integrations`, `compare`, `fit_check`,
`cases`, `demo_tour`, `onboarding`, `book_demo`). The package owns the
names, schemas, annotations, caps, the tier ladder and the discovery
documents; the product supplies only its data, a lead store and an
analytics callback.

```ts
// mcp.contract.ts
import { defineProductPublicServer } from "@inite/mcp/product";
export const publicMcp = defineProductPublicServer({
  product: "services", site: "https://inite.services", version: "0.1.0",
  title: "INITE Services", description: "CRM for service businesses with agents that close for you.",
  content: { whatItDoes, prices, integrations, compare, fitCheck, cases, demoTour, onboarding },
  lead: { store: (lead) => db.lead.create(...), notify: (lead, { id }) => ping(id) },
  onCall: (event) => db.funnelEvent.create({ data: event }),   // never arguments or PII
});

// app/mcp/route.ts
export const { POST, GET, OPTIONS } = publicMcp.route;
// app/.well-known/mcp/server-card.json/route.ts
export const { GET } = publicMcp.serverCardRoute;
// app/.well-known/mcp/route.ts (and mcp.json)
export const { GET } = publicMcp.wellKnownRoute;
```

- **Ladder** (Q11): 20 full answers per caller per day, then answers point to
  `book_demo`, from 50 sign-in at auth.inite.ai; a product-wide daily cap
  (5 000). A hosted client gets ×25 only when `isHostedEgress(ip)` proves the
  address. The memory bucket runs first; `counter` (the product's DB) after.
- **No prices** (Q12): `prices()` returns null and the tool answers `on_request`.
- **M6**: `cases` and `compare` items without a `source` are dropped.
- **M4/T10**: quotes and competitor claims are fenced with `untrusted()`.
- **Lint**: `expect(await checkProductServer(publicMcp)).toEqual([])` in the
  product's tests runs M1–M6 plus the static T1/T4/B1–B3 checks.
- `publicMcp.handle(request)` is the plain function for non-Next runtimes;
  `publicMcp.callTool(name, args, request)` serves the landing chat the
  same answers.
