# `@inite/mcp`

MCP (Model Context Protocol) server transport for `@inite/*` verticals. Bridges the existing `@inite/assistant` `ToolModule` registry to MCP so external clients (Claude Desktop, Cursor, Goose, ChatGPT, n8n) can call vertical tools directly. Per **ADR-003**.

## Install

```bash
pnpm add @inite/mcp@workspace:*
```

Peer dep: `zod ^3.25 || ^4`.

## Mount

```ts
// carRental: src/app/mcp/[companySlug]/route.ts
import { createMcpRoute } from "@inite/mcp/server";
import { authenticateMcpRequest } from "@/lib/mcp/auth";
import { CAR_RENTAL_TOOL_PERMISSIONS } from "@/lib/domain/assistant/toolPermissions";

export const { GET, POST } = createMcpRoute({
  toolModes: ["backoffice"],
  authenticate: authenticateMcpRequest,
  permissions: CAR_RENTAL_TOOL_PERMISSIONS,
  appsEnabled: true,
});
```

## Authenticator contract

Verticals supply how API keys / sessions resolve to a `ToolContext` and a `Set<permission>`:

```ts
import type { McpAuthenticator } from "@inite/mcp/server";

export const authenticateMcpRequest: McpAuthenticator = async ({ request, companySlug }) => {
  // 1. Parse Authorization: Bearer <key> or fall through to session cookie.
  // 2. Resolve companySlug → companyId, derive userRole, build permissions.
  // 3. Return { toolCtx, permissions } — or null to reject.
};
```

### Let MCP clients sign people in by themselves

Pass `resourceMetadataUrl` and serve the document (see `protectedResource` below). Claude, ChatGPT and Cursor then answer the 401 by sending the person through INITE sign-in and come back with a token; nobody installs the CLI or pastes a key.

```ts
export const { GET, POST } = createMcpRoute({
  toolModes: ["backoffice"],
  authenticate: authenticateMcpRequest,
  resourceMetadataUrl: "https://rentals.example/.well-known/oauth-protected-resource/mcp/acme",
});
```

## A site's own MCP server: `@inite/mcp/site`

For a public site (a shop, a blog, a portfolio) that wants AI agents to search it, read it and buy from it. No companies, no `@inite/assistant`, no dependencies.

Usually two endpoints:
- `/mcp`, open to any agent;
- `/mcp/account`, where the agent acts for a person who signed in with INITE. The agent's MCP client does the sign-in itself: it reads the 401, finds INITE Auth, registers and asks the person. The site needs no OAuth client of its own for this.

```ts
// lib/mcp.ts
import { createSiteMcp, protectedResource, jsonResult, textResult } from "@inite/mcp/site";
import { verifyAccessToken } from "@inite/auth";

const SITE = "https://www.example.com";
export const account = protectedResource({ site: SITE, path: "/mcp/account", name: "Example", documentation: `${SITE}/llms.txt` });

type Ctx = { reader: string | null };
export const mcp = createSiteMcp<Ctx>({
  name: "example",
  title: "Example",
  instructions: (ctx) => (ctx.reader ? "Signed in as the reader." : "Connect to /mcp/account to act for a reader."),
  tools: (ctx) => [
    {
      name: "search",
      description: "Search the site.",
      inputSchema: { type: "object", properties: { query: { type: "string" } }, required: ["query"] },
      annotations: { readOnlyHint: true },
      call: async ({ query }) => jsonResult({ results: await search(String(query)) }),
    },
  ],
});

// app/mcp/route.ts
export const { POST, GET, OPTIONS } = mcp.route({ context: () => ({ reader: null }) });

// app/mcp/account/route.ts
export const { POST, GET, OPTIONS } = mcp.route({
  resource: account,
  authenticate: (token, aud) => verifyAccessToken(token, { audience: aud }).catch(() => null),
  context: (_req, claims) => ({ reader: (claims as { sub: string }).sub }),
});

// app/.well-known/oauth-protected-resource/[[...path]]/route.ts
export const GET = protectedResourcesRoute([account]);

// app/.well-known/mcp.json/route.ts
export const GET = () => mcpCardResponse({ site: SITE, name: "example", title: "Example", description: "…",
  endpoints: [{ path: "/mcp" }, { path: "/mcp/account", resource: account }] });

// app/.well-known/mcp-registry-auth/route.ts  (to publish in the official MCP registry)
export const GET = () => mcpRegistryAuthResponse("<base64 ed25519 public key>");
```

A tool that throws becomes an error result the agent can read; the exception text stays in the log. `textResult(text, isError)` and `jsonResult(value)` build answers. For buying, pair it with `@inite/billing/purchases`: open a session, try `payFromWallet` for a signed-in reader, otherwise return `checkoutUrl` and `x402Url`.

### One endpoint, sign-in only where a tool needs it

Two endpoints mean an agent has to be connected twice. Instead, one `/mcp` can serve anonymous agents and act for a person in the same place: give the route `signIn: "optional"`, and mark the tools that act for a person `signedIn` (`true`, or `{ scope, when }`). Calling such a tool without a token answers HTTP 401 with `WWW-Authenticate: Bearer resource_metadata="…", scope="shop:purchase"`, so the client signs the person in exactly then; a token without the scope gets 403 `insufficient_scope`. A token that is sent is checked on every request, and a bad one is a 401 at once, even for a public tool.

```ts
const shop = protectedResource({ site: SITE, path: "/mcp", name: "Example", scopes: ["shop:purchase"] });

const mcp = createSiteMcp<Ctx>({
  name: "example",
  websiteUrl: SITE,
  onToolCall: ({ tool, outcome, ms }) => count(tool, outcome, ms), // never sees the arguments
  tools: [
    { name: "search", inputSchema, parse: (a) => SearchInput.safeParse(a), call: (args) => result(text, data) },
    { name: "buy", inputSchema, signedIn: { scope: "shop:purchase" }, call: (args, ctx) => buy(ctx.person) },
    // Only some calls need the person: book anonymously, or with their profile.
    { name: "book", inputSchema, signedIn: { scope: "shop:booking", when: (a) => a.useProfile === true }, call },
  ],
});

export const { POST, GET, OPTIONS } = mcp.route({
  resource: shop,
  signIn: "optional",
  authenticate: (token, aud) => verifyAgentToken(token, { audience: aud }), // @inite/auth/agent; has .scopes
  context: (req, person) => ({ person }),
  beforeRequest: (req) => rateLimit(clientIp(req)), // a Response refuses, null lets it through
  maxBodyBytes: 256 * 1024, // the default; 413 above it
});
```

`parse` takes zod's `safeParse` as it is (or any `{ success, data | error }`); bad arguments come back to the agent as an error result that names the problem, and `call` gets the parsed values. `result(text, data)` answers with words for the person and the same facts as `structuredContent`. A scoped tool checks `scopes` on whatever `authenticate` returned (`verifyAgentToken` has them); an authenticator that reports no scopes is trusted as it is. Without `signIn: "optional"` a route with `resource` needs the person on every request, as before.

Working examples: neuralcosmology.com (`/mcp`, `/mcp/account`), mikefluff.com (`/mcp`, one endpoint), billing.inite.ai/mcp/wallet.

### Cards in the chat (MCP Apps, ChatGPT)

A tool's answer can show as a card instead of JSON: in Claude, VS Code and other MCP Apps hosts (`_meta.ui.resourceUri` → a `ui://` resource, `text/html;profile=mcp-app`) and in ChatGPT (`openai/outputTemplate`). One HTML serves both: the runtime reads `window.openai.toolOutput` or the MCP Apps `ui/notifications/tool-result` message. Clients without UI get the text answer, so always return both (`jsonResult` does).

Two ready cards for anything a site sells:

```ts
import { catalogApp, orderApp } from "@inite/mcp/site";

const catalog = catalogApp("mysite", ["https://www.mysite.com"]);   // image domains
const order = orderApp("mysite", ["https://www.mysite.com"]);

createSiteMcp({
  name: "mysite",
  apps: [catalog, order],
  tools: [
    { name: "list_books", ui: { app: catalog, invoking: "Looking…", invoked: "Books" },
      call: () => jsonResult({ items: [{ title, subtitle, image, price: "$15", url,
                                         action: { tool: "create_checkout", arguments: { item }, label: "Buy" } }] }) },
    { name: "create_checkout", ui: order,
      call: () => jsonResult({ title, image, price: "$15", status: "open", checkoutUrl, approveUrl, x402Url }) },
  ],
});
```

- **Catalog**: covers, prices, a Buy button that calls the tool you name, an Open button for the page.
- **Order**: what is bought and every way to pay. "Pay from INITE wallet" opens the approve page (passkey), "Pay by card or PIX" the payment page; paid/confirming shows as done.
- Your own card: `app({ uri, name, css, script })` gets the same light/dark base and `INITE.onData(render)`, `INITE.openLink(url)`, `INITE.callTool(name, args)`, `INITE.esc(text)`.

## Titles and behaviour hints

Every tool is published with a `title` and all four MCP hints (`readOnlyHint`, `destructiveHint`, `idempotentHint`, `openWorldHint`), on both `createMcpRoute` and `@inite/mcp/site`. App directories (ChatGPT, Claude) flag tools without them, and clients use them to decide when to ask the person first.

Whatever a tool declares is kept (`title`/`annotations` on a site tool; `title`/`annotations` on an `@inite/assistant` tool). The rest comes from the name: `get_/list_/search_/…` are read-only, `delete_/cancel_/revoke_/release_/…` are destructive, the title is the name made readable. Declare the hints when the name could mislead (`toolAnnotations` in `@inite/mcp` shows what will be published).

## Sub-paths

- `@inite/mcp/server` — `createMcpRoute`, `bridgeTools`, `FetchTransport`
- `@inite/mcp/site` — `createSiteMcp`, `result`, `protectedResource`, `protectedResourcesRoute`, `mcpCard`, `mcpRegistryAuthResponse`
- `@inite/mcp/apps` — `buildToolResult` for ADR-001 ext-apps responses
- `@inite/mcp/prompts` — `registerSkillsAsPrompts` (used by `@inite/skills`)

## Design constraints

- Stateless: one `McpServer` per request, no session state. Matches `inite-brain-service` pattern.
- Web `Request` / `Response` only — built for Next.js App Router route handlers, not Express.
- No domain knowledge. Tool permission map + auth callback come from the consumer.

## Related

- `ADR-003: MCP Server + Skills` — locked contract.
- `ADR-001: Composable UI Two-Path Envelope` — `buildToolResult` implements path 2 of this ADR.
- `@inite/assistant` — the tool registry this package bridges from.
