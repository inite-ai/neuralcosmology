# @inite/billing

The INITE billing service from a site's side: subscriptions, the price catalog
and one-time purchases. Billing keeps the money, the rails, the receipts and
the refunds; a site asks it for a checkout session and later asks whether the
order was paid.

## The reader's currency: `@inite/billing/currency`

The owner decided on 23.11.2026 that country and language only pick the
default. The binding is soft:

1. **The reader's own choice.** It is kept in the family cookie
   `INITE_CURRENCY` (a three-letter code, `Path=/`, one year, `SameSite=Lax`),
   the way `NEXT_LOCALE` keeps the language. `@inite/landing`'s
   `CurrencySwitcher` writes it; every product with prices puts the switcher
   in its footer (`FamilyFooter`'s `currency` slot).
2. **Otherwise the country.** It is read from Cloudflare's `CF-IPCountry`:
   BR gives BRL, MX gives MXN, CL gives CLP, CO gives COP, AR gives ARS, RU
   gives RUB, the euro area gives EUR, any other country gives USD.
3. **Otherwise the page language.** This applies only when there is no
   country, as on a local run or for a crawler: pt gives BRL, ru gives RUB,
   anything else gives USD.

Every step is limited to `available`: the currencies the product has live
prices in, read from billing (`planCurrencies(await billing.plans())`).
Billing adds currencies in stages, so a product never lists them in code. A
choice the product has no price in falls back to the default. Anything else
is USD, and no price is invented. The language keeps picking the words and
the number format (`@inite/utils/intl` `formatMoney`), never the currency.

```ts
import { planCurrencies, requestCurrency } from "@inite/billing/currency";
const currency = requestCurrency(await headers(), { lang, available: planCurrencies(plans) });
```

### What is charged

The switch changes the display only. The currency charged is decided at
checkout. A local Latin American currency (BRL, MXN, CLP, COP, ARS) is
charged only with proof of the country: the payment rail, the card's country
or a tax id. Without proof the charge is in USD. `INITE_CURRENCY`,
`CF-IPCountry` and the page language are not proof.

`billingCheckoutRoute` sells the price code it is sent and checks no proof.
Until checkout checks it, a product sends that route a local Latin American
price code only with proof in hand, and the USD code otherwise.

### Caching

Server-rendered prices read the cookie, so the first paint after a switch
is right. A page cached per language (ISR, static, a CDN keyed on the URL)
must not bake a currency in. Pick one of these:
- render it per request;
- vary the cache on `Cookie` and `CF-IPCountry`;
- draw the price on the client with `useChosenCurrency(serverDefault, currencies)`
  from `@inite/landing`, which follows a switch without a reload.

## One-time purchases: `@inite/billing/purchases`

A buyer can pay a session three ways, and the site does almost nothing extra
for the last two:

1. **The payment page** (`checkoutUrl`): card, PIX, crypto, whatever billing's
   rails take.
2. **An AI agent with its own wallet** pays by x402 at `x402Url` (USDC on Base).
   Hand that URL to the agent next to the payment link. It is there only when
   billing can take x402.
3. **The buyer's INITE wallet.** If the buyer has allowed this site to charge
   their wallet, `payFromWallet` pays straight away. If not, billing returns
   one page on auth.inite.ai where they make a wallet if they have none, allow
   the site with limits (per payment, per month) using their passkey, top up
   if short, and pay this purchase. Next time no page is needed.

```ts
import { createBillingPurchases, checkoutUrlIn } from '@inite/billing/purchases'

export const billing = createBillingPurchases({
  url: process.env.BILLING_SERVICE_URL!,       // https://billing.inite.ai
  apiKey: process.env.BILLING_SERVICE_API_KEY!, // the site's service key
  site: 'mysite',                               // prefix for buyers without an account
  // walletPay: false,                          // never try the INITE wallet
})

// A buyer with an INITE account is their DID; without one, a hash of their email.
const userId = session?.userId ?? billing.guestUserId(email)

const s = await billing.createPurchase({
  priceCode: 'book-usd',
  userId,
  successUrl: 'https://mysite.com/thanks',
  errorUrl: 'https://mysite.com/book',
  locale: 'pt',                // billing's page and emails in the buyer's language
  idempotencyKey: requestId,
})

// Signed-in buyer (or an agent acting for one): try the wallet first.
const paid = session ? await billing.payFromWallet(s.sessionId, userId, { returnTo: pageUrl }) : null
if (paid?.status === 'paid') {
  // done, or `confirming` for a minute or two while Base makes it final
} else if (paid?.status === 'needs_approval') {
  redirect(paid.approveUrl) // `reason`: no_wallet | not_approved | over_limit | insufficient_funds
} else {
  redirect(checkoutUrlIn(s.checkoutUrl, locale)) // and give agents s.x402Url
}
```

`payFromWallet` never throws. Anything unexpected, including a billing that
does not offer it yet (404), comes back as `unavailable`, and the buyer pays
on the payment page. The approve link is accepted only on `https://*.inite.ai`.

Whether an order is paid is only ever what `getOrder(id)` says; nothing the
browser brings back counts.

Guest orders: when someone signs in with an email the identity provider has
verified, call `claimGuestPurchases(userId, email)` and the orders they made
as `guestUserId(email)` on this site move onto their account. Never with an
unverified email.

The module has no imports beyond `node:crypto`, so a site outside the pnpm
workspace can vendor the packed package (see mikefluff-site's
`scripts/sync-inite-auth.mjs` for the pattern).

Billing's side of all this: `docs/wallet.md` and `docs/x402.md` in
inite-billing-service; people-facing pages at billing.inite.ai/docs/wallet and
auth.inite.ai/docs/agents.

## Subscriptions: `@inite/billing/subscriptions`, `/plans`, `/webhooks`, `/checkout-route`, `/react`

A product that sells plans mounts four things. Billing is the only place a
price lives: the pricing page renders billing's catalogue, and a number typed
into a page or a locale file is a defect (`payments-through-billing`).

```ts
// lib/billing.ts
import { createBillingSubscriptions } from '@inite/billing/subscriptions'
export const billing = createBillingSubscriptions({
  url: process.env.BILLING_SERVICE_URL!,        // https://billing.inite.ai
  apiKey: process.env.BILLING_SERVICE_API_KEY!,  // the service key, server only
  service: 'rent',                               // entitlements rent:plan:<tier>
  productPrefix: 'inite-rent',                   // when product codes differ from `service`
})

// app/api/billing/checkout/route.ts — the picker's forms post here
import { billingCheckoutRoute } from '@inite/billing/checkout-route'
export const POST = billingCheckoutRoute({
  billing,
  origin: 'https://inite.rent',
  subscriber: currentSubscriber,                 // (req) => the DID, or the org a company plan is for; null if signed out
  signIn: (back) => `/api/auth/login?returnTo=${encodeURIComponent(back)}`,
})

// app/api/billing/webhook/route.ts — billing's Service.webhookUrl
import { billingWebhookRoute } from '@inite/billing/webhooks'
export const POST = billingWebhookRoute({
  secret: process.env.BILLING_SERVICE_API_KEY!,  // billing signs with the service key
  ledger: dbLedger,                              // claim(eventId) on a unique row
  on: { 'billing.subscription.updated': (e) => refreshPlan(eventUserId(e)) },
})

// app/[lang]/pricing/page.tsx
import { PlanPicker } from '@inite/billing/react'
<PlanPicker plans={await billing.plans()} locale={lang} labels={t.pricing}
  interval={sp.billing === 'year' ? 'year' : 'month'} intervalHref={(i) => `?billing=${i}`}
  current={(await billing.plan(uid))?.productCode} />
```

- `plans()` reads the service's own products (billing scopes the list to the
  key) and keeps them five minutes; a failed read serves the last list.
  Currency by locale: `pt` pays in reais, everyone else in dollars, falling
  back to dollars where a plan has no BRL price. The annual saving is worked
  out from billing's two prices, never a constant.
- `entitled(subscriber, key)` answers `{ granted, known }`; `known: false`
  means billing could not be asked, and a paid feature stays shut.
  `plan(subscriber)` is the highest plan whose keys are all held.
- `portalUrl({ locale, returnTo })` is billing's page where a person cancels
  and resumes.
- A webhook is a nudge: re-read entitlements on it, never trust its body for
  what was paid. The route answers 200 to a duplicate and 500 when a handler
  throws (and gives the event id back), so billing's retry is acted on.

The design and the per-product rollout: `.planning/family-subscriptions-2026-10.md`.
