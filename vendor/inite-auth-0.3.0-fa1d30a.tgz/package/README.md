# @inite/auth

Sessions, tokens, permissions and sign-in with INITE for the inite.* sites.

## Sign-in with INITE: one kit for every family product (0.3)

Every product signs in only through auth.inite.ai, through this kit, on the
same paths. Nothing below is a per-product choice: the paths are constants
(`@inite/auth/contract`), and auth.inite.ai derives each first-party client's
redirect, back-channel and post-logout URLs from its origin with the same
paths. `inite-standards check` fails a repo that serves the back-channel route
anywhere else, keeps its own JWT or OAuth code, hashes passwords or accepts
HS256.

| Path | What |
|---|---|
| `/api/auth/login` | GET `?return_to=/path[&register=1][&organization=<id or slug>][&customer=1]`: start a sign-in (org switch = re-authorize; `customer=1` = the customer lane) |
| `/callback` | the registered redirect URI; the code is exchanged on the server |
| `/api/auth/logout` | GET or POST `?return_to=/path`: end the session here and at the IdP |
| `/api/auth/refresh` | POST: renew the access token (the refresh token stays an httpOnly cookie). 401 and cleared cookies only when the IdP refuses the token; 503 with the cookies kept when it does not answer |
| `/api/auth/backchannel-logout` | POST `logout_token`: OIDC Back-Channel Logout, a jti accepted once |
| `/api/auth/userinfo` | GET: who is signed in and which tenant, never a token |
| `/api/auth/demo` | GET or POST `?persona=owner\|manager\|staff&return_to=/path`: the demo button; 404 unless `demo: { enabled: true }` |
| `/api/auth/telegram` | POST `{ init_data }` from the product's own page: a Telegram Mini App signs in as the INITE account linked to that Telegram id; 404 unless `telegram: { enabled: true }` |

Env, the same names everywhere: `INITE_AUTH_CLIENT_ID`, `INITE_AUTH_CLIENT_SECRET`,
`INITE_AUTH_COOKIE_SECRET` (optional), `APP_URL`, and `INITE_AUTH_ISSUER` only
for a local dev IdP. `OAUTH_CLIENT_ID`/`OAUTH_CLIENT_SECRET` are read as fallbacks.

### Next.js (`@inite/auth/next`)

```ts
// lib/auth.ts
import { createIniteAuth } from '@inite/auth/next'
export const auth = createIniteAuth({ revocations, onSignIn: ensureTenantRow })

// app/api/auth/[...inite]/route.ts   export const { GET, POST } = auth.route
// app/callback/route.ts              export const { GET } = auth.route
// proxy.ts                           export const proxy = (req) => auth.proxy(req, { protect: ['/app'] })
```

```ts
const session = await auth.getSession()            // server component / action
const session = await auth.sessionFromRequest(req) // route handler
// { userId (DID), email, emailVerified, name, label, isAdmin (platform_role only),
//   org: { id (auth org UUID = the tenant), companyId, slug, role } | null, demo, scopes, claims }
```

The tenant is the auth org: key the product's own tenant row by `session.org.id`
(create it on first sight in `onSignIn`), and keep no users, companies or
memberships of the product's own.

### Express and Nest (`@inite/auth/node`)

```ts
const auth = createIniteAuthNode({ revocations })
app.use(auth.router)                                       // /api/auth/* and /callback
app.get('/api/me', auth.requireSession, (req, res) => res.json(req.inite))
```

### APIs and MCP (`@inite/auth/resource`)

```ts
const verifyBearer = createResourceVerifier({ audience: 'https://inite.rent/mcp' })
const session = await verifyBearer(request, { scopes: ['rent:read'] })
```

### The browser (`@inite/auth/client`)

`useIniteSession()`, `fetchSession()`, `refreshSession()`, `switchOrgHref()`,
`signInHref()`, `signOutHref()`, `demoSignInHref()`, `customerSignInPath()`,
`isDemo()`, `isCustomer()`, `isStaff()`. The page never sees a token.

`signIn()` starts a sign-in from this page. Every sign-in link drops the query
params that only open UI on a page (`UI_ONLY_PARAMS`: `auth`, `chat`) from
`return_to`, so a person who signs in from `/feed?auth=login` lands on `/feed`,
not in front of the sign-in modal again. `signInHref(path, { dropParams })`
takes another list (`[]` keeps the path as written); `cleanReturnTo()` is the
same step on its own. `fetchSession()` answers `offline: true` when the network
is down, so a page keeps what it knew; concurrent `refreshSession()` calls share
one request, since refresh tokens rotate.

### Telegram Mini App (0.3)

Inside a Mini App there is no page to redirect through, so the app posts
`Telegram.WebApp.initData` to `/api/auth/telegram`. The kit passes it to
auth.inite.ai (`POST /v1/auth/telegram/webapp`), which alone checks the bot's
signature and `auth_date`, finds or creates the INITE account linked to that
Telegram id, and answers an authorization code for this client. The kit redeems
it like `/callback` does (PKCE, the client secret) and sets the same httpOnly
cookies; `onSignIn` runs. The answer is `{ ok: true }` or `{ error }`:
`telegram_unavailable` (off here or at auth, or the bot not bound to the client),
`telegram_refused` (signature, age, consent), `telegram_failed`. A post whose
`Origin` is another site, or `Sec-Fetch-Site` is not `same-origin`, gets 403.

```ts
const auth = createIniteAuthNode({ revocations, telegram: { enabled: true } })
// in the Mini App
await fetch('/api/auth/telegram', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ init_data: Telegram.WebApp.initData }) })
```

auth.inite.ai needs `TELEGRAM_PROVIDER_ENABLED=true`, the bot in `TELEGRAM_BOTS`
bound to the client id, its `TELEGRAM_BOT_TOKEN_<NAME>`, and the client
first-party (a Mini App cannot show a consent screen).

### The demo button (0.3)

auth.inite.ai's demo grant (inite-auth-service #276, `DEMO_GRANT_ENABLED`) gives
a product's backend, authenticated as itself, a read-only two-hour token of a
persona of «Atlântica Group (demo)»: Ana (`owner`), Bruno (`manager`), Carla
(`staff`). The kit asks for it on the server and signs the visitor in with it.

```ts
export const auth = createIniteAuth({ revocations, demo: { enabled: process.env.DEMO_ENABLED === '1' } })

// a button, from any page
<a href={demoSignInHref('owner', '/app')}>Open the demo</a>

// or by hand, on the server
const grant = await auth.demo('manager')   // { accessToken, expiresIn: 7200, session } | null
```

- Off by default: without `demo.enabled` the route answers 404 and `auth.demo()`
  returns null without calling auth.
- Only an access cookie is set (no refresh cookie; one left from an earlier
  session is cleared), plus the readable `demo_session=<end, Unix seconds>`.
  After two hours the visitor is signed out.
- A token auth returns is used only when this product accepts it and it says
  `demo: true`.
- Per address, 5 demo sign-ins a minute; per process, 30 (auth's own per-client
  limit). `demo.clientIp` reads the address (default `cf-connecting-ip`,
  `x-real-ip`, then the first `x-forwarded-for` hop); `perIpPerMinute`,
  `perMinute` tune the buckets.
- Read-only is the product's job too: the token carries `<product>:read` only,
  and every write choke point calls `assertNotDemo(session)` (it throws
  `AuthForbiddenError`, `status` 403, `code` `demo_read_only`).

### The demo tenant, its button and banner (`@inite/auth/demo`, `/demo-ui`)

Every product's demo data hangs off the one demo tenant: a local tenant row
whose `authOrgId` is `DEMO_ORG_ID` (auth's «Atlântica Group (demo)»,
`a7a71c00-de00-4000-8000-000000000001`). A demo session's `org.id` is that id,
so the product resolves the session to that row and to nothing else.

```ts
import { DEMO_ORG_ID, isDemoTenant, DEMO_ORG_ROLES } from '@inite/auth/demo'
isDemoTenant(company)          // company.authOrgId === DEMO_ORG_ID: noindex, no mail, no checkout

import { DemoBanner, DemoSignInButton } from '@inite/auth/demo-ui'   // client components
<DemoBanner lang={lang} />                                          // root layout: time left + «Выйти из демо»
<DemoSignInButton lang={lang} returnTo="/admin" className="btn" />  // «Войти в демо» / «Try the demo»
```

The banner reads the `demo_session` cookie after mount (no request), counts
down, and links to `/api/auth/logout`. Copy in ru, en, pt, es; `--inite-demo-bg`
and `--inite-demo-fg` theme it, or pass a `className`.
It sits fixed at the bottom by default (`placement="bottom"`), above the
device's safe area, with a spacer so the page's last lines stay visible; a
product with its own fixed bottom bar sets `--inite-demo-bottom` to that bar's
height. `placement="top"` keeps a sticky top bar for pages with no fixed header.

One demo kit for every product (22.11.2026; Studio's `demo-banner.tsx` and
Break3's `DemoBanner.js` were forks of the bar):

| Piece | Where | What |
|---|---|---|
| `DemoBanner` | `/demo-ui` | the bar: made-up data, time left, the way out |
| `DemoSignInButton` | `/demo-ui` | «Войти в демо» to the product's demo door |
| `DemoPersonaPicker` | `/demo-ui` | Ana (owner), Bruno (manager), Carla (staff): one link each, with what they see |
| `DemoNotice` | `/demo-ui` | a demo storefront's line: made-up data, an order reaches only the demo back office (food's `DemoStorefrontNotice`, lifted) |
| `DEMO_COPY`, `formatDemoLeft`, `readDemoEnd`, `DEMO_BAR_HEIGHT_VAR` | `/demo-core` | the same words and clock without React, for a bar in another stack (CRA, Studio's dashboard) |
| `defineDemoSeed`, `checkDemoSeed`, `demoSeedIsIdempotent`, `demoPersonaEmail` | `/demo-seed` | how a back office joins the demo |
| `guardDemoAction`, `demoReadOnly`, `isDemoReadOnly`, `requestIsDemo`, `demoWriteRefused`, `isServerActionRequest`, `demoApiRefusal`, `isDemoApiRefusal` | `/demo-guard` | a demo write refused with a toast, never an error screen |

The words are in `src/locales/<lang>/demo.json` (ru, en, pt, es).

#### A write in the demo: a toast, never an error screen

A demo session writes nothing (`assertNotDemo` at every write choke point).
The person must see why, in a toast, and the page must not break:

- **The proxy:** one question for a demo session, and it must not be
  answered by hand:

  ```ts
  import { demoApiRefusal, demoWriteRefused, requestIsDemo } from "@inite/auth/demo-guard";
  if (requestIsDemo(request) && demoWriteRefused(request, { handlers: ["/uploads"] })) return demoApiRefusal();
  ```

  It refuses every write (403, problem+json, `code: "demo_read_only"`) but
  `/api/auth/` (`open` replaces that list) and a page's server action. The
  page checks `await isDemoApiRefusal(res)`. `handlers` names the product's
  own route handlers outside `/api` that take writes. `requestIsDemo` reads
  the bearer and the cookie.
- **`Next-Action` proves nothing.** Any client can send it, and a route
  handler ignores it. Until 24.11.2026 `isServerActionRequest` looked at the
  header alone, so a demo session could write to the API through a proxy that
  let "server actions" pass. It now needs the path (a `Request`, a
  `NextRequest` or `{ method, headers, pathname }`) and is false under any
  `api` segment, for agent paths and for `handlers`; without a path it does not
  compile and throws. It is a question for the proxy: an action guard never
  asks it, it refuses the demo with `guardDemoAction`. The
  handlers' own `assertNotDemo` stays: the proxy is not the only guard.
- **Server actions:** the proxy passes a page's to its guard. A form sent
  without JavaScript carries no `Next-Action` and is refused, and so is an
  action on a page with an `api` segment in its path.
  A JSON 403 to a server action crashes the page
  into its error boundary (inite.food, 23.11.2026). Each writing action is
  wrapped instead: `return guardDemoAction(session, () => save(input))`, which
  returns `demoReadOnly()` (`{ ok: false, code: "DEMO_READ_ONLY" }`) for a demo
  session.
- **The toast:** `if (isDemoReadOnly(result)) toast(demoReadOnlyMessage(lang), "info")`,
  the family toast from `@inite/ui`; the words ("This is a demo: nothing is
  saved.") are in ru, en, pt and es.

#### How a back office joins the demo

```ts
import { defineDemoSeed, demoSeedIsIdempotent } from '@inite/auth/demo-seed'

export const demoSeed = defineDemoSeed({
  product: 'shop',
  tenant: { name: 'Atlântica Store (demo)' },
  personas: { owner: { name: 'Ana Souza' }, manager: { name: 'Bruno Lima' }, staff: { name: 'Carla Dias' } },
  async seed(db) { /* upsert the tenant row (authOrgId: DEMO_ORG_ID) and its fixtures, by fixed ids */ },
  async reset(db) { /* back to what seed() wrote */ },
})

// the product's test, on its throwaway database:
expect(await demoSeedIsIdempotent(demoSeed, db, readDemoRows)).toEqual([])
```

The contract: the tenant row's `authOrgId` is `DEMO_ORG_ID`; each persona
has a person (an address, when kept, is `demoPersonaEmail(persona)`, at
`demo.inite.ai`); `seed()` is idempotent (upserts by fixed ids); `reset()`
returns to what `seed()` wrote; nothing in it mails, charges, calls a model
or posts outside the product; the deploy runs `seed()` after migrations and
the product's clock runs `reset()` at least daily. Then `demo: { enabled }`,
`DemoBanner` in the root layout and `DemoPersonaPicker` on the sign-in page.

A demo storefront (`demo: true` on the `StorefrontTenant`) never gets an org
of its own: `sync` refuses it, `syncQuietly` skips it, and the backfill plans
it as `skip` with reason `demo`.

### The customer lane (0.3)

A tenant's own customers (a restaurant's guests, a shop's buyers) are INITE
accounts, signed in passwordless, with the org role `customer` in the tenant's
org. A storefront sends them to sign in with the org hint and the marker:

```ts
<a href={customerSignInPath(tenant.slug, '/orders')}>Sign in</a>   // /api/auth/login?…&organization=<slug>&customer=1
auth.customerLoginHref(tenant.slug, '/orders')                     // the same, on the server
signInHref('/orders', { organization: tenant.slug, customer: true })
```

A customer is never staff and never admin: `session.customer` is true,
`session.isAdmin` is false whatever `platform_role` says, `isCustomer(session)`
and `assertStaff(session)` guard staff code, `auth.requireStaff()` (Next) and
`auth.requireStaff` (Node middleware) refuse them with a 403, and
`auth.proxy(req, { staff: ['/admin'] })` keeps them off staff paths. On the
legacy path `requirePermission`, `getEffectivePermissions`,
`requireCompanyAccess` and `verifyOwnership` refuse a session whose `orgRole`
is `customer`.

### Storefront Telegram (`@inite/auth/storefrontTelegram`)

A tenant's customers may also come from the tenant's own Telegram bot's Mini
App. They stay the tenant's customers (the product's customer session), the
INITE customer lane above is the option beside it, and no product checks
initData by hand:

```ts
import { signInStorefrontTelegram, memoryReplayStore } from '@inite/auth/storefrontTelegram';

const replay = memoryReplayStore(); // one process; pass a shared store with more
const r = await signInStorefrontTelegram({
  initData, botToken: tenantInbox.botToken, replay, scope: company.id,
  signIn: async ({ user }) => upsertCustomerAndSetSession(company.id, user), // the product's rows and cookie
});
if (!r.ok) return Response.json({ error: r.reason }, { status: r.status });
```

The check signs every field but `hash` (`signature` included), compares in
constant time, refuses a payload older than a day or more than a minute ahead,
and one payload signs in once. `decideStorefrontIniteLink` and
`decideStorefrontTelegramLink` say which customer row a sign-in lands on: a row
is linked only when nothing contradicts it (never a second INITE sub or a
second Telegram id), an email links only when INITE verified it.

### Storefront orgs (`@inite/auth/storefrontOrgs`)

The customer lane admits a customer only into an active org in auth that
names the product's client. The product keeps those orgs in step with its
tenants through auth's machine endpoint (inite-auth-service issue #304), never
by hand: on tenant create, update and deactivate, and once as a backfill.

```ts
import { storefrontOrgs, syncQuietly, runBackfill } from '@inite/auth/storefrontOrgs';

const orgs = storefrontOrgs({
  clientId: process.env.OAUTH_CLIENT_ID!, clientSecret: process.env.OAUTH_CLIENT_SECRET!,
  prefix: 'shop-', // the prefix auth holds for this client
});
await syncQuietly(orgs, { id: store.id, slug: store.slug, name: store.name, active: store.active });
kit.customerLoginHref(orgs.slugFor(store.slug)!, '/'); // the button sends the prefixed slug
```

The org slug is the prefix plus the storefront slug, so a shop and a
restaurant both called "pizza" never collide. `syncQuietly` never fails the
product's own save: a missed sync is caught by the next update or the
backfill. `runBackfill(orgs, prefix, tenants, apply)` plans against the orgs
auth holds (create, update, unchanged, skip) and writes only with `apply`.

### What the kit refuses, with no option to turn it off

`alg: none`, HS256 (with any secret), another issuer, another audience, an
expired token, a key the IdP does not publish, a replayed `logout_token`,
`roles ∋ admin` or `metadata.isAdmin` read as platform admin. `getSession`
(the legacy local-user session) refuses the same, and accepts no token at all
when the product has no audience configured. On the legacy path too, admin is
the token's `platform_role` on each request: `isSuperadmin` reads
`session.platformRole`, `session.role` is `superadmin` only while the token
says so, and a local row's `superadmin` is written back to `user` when it no
longer does. `getSession` and `getSessionFromBearer` honour back-channel
logouts when given the store (`setSessionRevocations(store)` once at boot, or
`getSessionFromBearer(token, { revocations })`). Local sign-in
(`loginWithCredentials`, `mintLocalAccessToken`) is deleted.

Buttons, from a client component:

```ts
import { signInHref, signOutHref } from '@inite/auth/sign-in'
<a href={signInHref(pathname)}>Sign in</a>
```

What it takes care of:

- **PKCE without storage.** The verifier, state and return path travel as an
  AES-GCM-sealed, httpOnly cookie filed under the state and scoped to the
  callback path. Every tab has it, so a magic link that opens in a new tab
  completes; no `oAuthState` table.
- **Server-side callback.** No client page, no fetch; failures land on the
  return path with `?auth_error=`. A replayed callback from a browser that is
  already signed in just continues.
- **Email is optional.** Wallet (SIWE) accounts have none; `label` is what to
  display.
- **Audience and issuer are checked** against JWKS (`clientId` and the API URL
  by default).
- **`return_to` is only ever a path on the site.**

Environment: `OAUTH_CLIENT_SECRET` must be set; the redirect URI registered for
the client is `<site origin>/callback`.

## Server to server: `MachineTokenClient`

`client_credentials` for a backend calling brain, inbox or billing. The token
endpoint is the issuer's `token_endpoint` from
`<AUTH_SERVICE_URL>/.well-known/openid-configuration` (cached per base URL;
only https or the base URL's own origin), else `<base>/v1/oauth/token`.
`tokenEndpoint` overrides both. (Up to 0.2 it posted to `<base>/oauth/token`,
which is 404 on auth-api.inite.ai.)

## Tokens that AI agents bring: `@inite/auth/agent`

When a person connects an AI agent (Claude, ChatGPT, Cursor) to a site's MCP
endpoint, the agent signs in with INITE for them. Its token names both: `sub`
is the person, `act` is the agent (its own did:web and the app it runs in).
The person sees every connected agent in their INITE account and can
disconnect it there.

```ts
import { verifyAgentToken, mayPayFromWallet } from '@inite/auth/agent'

const t = await verifyAgentToken(bearer, { audience: 'https://www.example.com/mcp/account' })
// null → answer 401 (see protectedResource in @inite/mcp/site)
t.person          // whose account, orders and books
t.agent           // { id: 'did:web:auth.inite.ai:agents:…', clientId } or null for the person themselves
t.email, t.emailVerified, t.scopes
t.wallet          // { perPayment, daily, monthly, currency, merchants } when the person allowed spending
mayPayFromWallet(t)
```

The wallet limits are enforced by billing; the site only decides whether to
offer paying from the wallet at all.

## After sign-in: `onSignIn`

```ts
export const auth = createIniteAuth({
  clientId, clientSecret,
  onSignIn: async (session) => {
    // Orders made as a guest with this email move onto the account.
    if (session.email && session.emailVerified) await billing.claimGuestPurchases(session.userId, session.email)
  },
})
```

Runs once per sign-in, before the redirect. If it fails, the error is logged
and the person is still signed in.
