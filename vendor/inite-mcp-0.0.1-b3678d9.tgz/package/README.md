# `@inite/mcp`

MCP (Model Context Protocol) server transport for `@inite/*` verticals. Bridges the existing `@inite/assistant` `ToolModule` registry to MCP so external clients (Claude Desktop, Cursor, Goose, ChatGPT, n8n) can call vertical tools directly. Per **ADR-003**.

## Install

```bash
pnpm add @inite/mcp@workspace:*
```

Peer dep: `zod ^3.25 || ^4`.

## Mount

```ts
// carRental: src/app/mcp/[companySlug]/route.ts
import { createMcpRoute } from "@inite/mcp/server";
import { authenticateMcpRequest } from "@/lib/mcp/auth";
import { CAR_RENTAL_TOOL_PERMISSIONS } from "@/lib/domain/assistant/toolPermissions";

export const { GET, POST } = createMcpRoute({
  toolModes: ["backoffice"],
  authenticate: authenticateMcpRequest,
  permissions: CAR_RENTAL_TOOL_PERMISSIONS,
  appsEnabled: true,
});
```

## Authenticator contract

Verticals supply how API keys / sessions resolve to a `ToolContext` and a `Set<permission>`:

```ts
import type { McpAuthenticator } from "@inite/mcp/server";

export const authenticateMcpRequest: McpAuthenticator = async ({ request, companySlug }) => {
  // 1. Parse Authorization: Bearer <key> or fall through to session cookie.
  // 2. Resolve companySlug → companyId, derive userRole, build permissions.
  // 3. Return { toolCtx, permissions } — or null to reject.
};
```

### Let MCP clients sign people in by themselves

Pass `resourceMetadataUrl` and serve the document (see `protectedResource` below). Claude, ChatGPT and Cursor then answer the 401 by sending the person through INITE sign-in and come back with a token; nobody installs the CLI or pastes a key.

```ts
export const { GET, POST } = createMcpRoute({
  toolModes: ["backoffice"],
  authenticate: authenticateMcpRequest,
  resourceMetadataUrl: "https://rentals.example/.well-known/oauth-protected-resource/mcp/acme",
});
```

## A site's own MCP server: `@inite/mcp/site`

For a public site (a shop, a blog, a portfolio) that wants AI agents to search it, read it and buy from it. No companies, no `@inite/assistant`, no dependencies.

Usually two endpoints:
- `/mcp`, open to any agent;
- `/mcp/account`, where the agent acts for a person who signed in with INITE. The agent's MCP client does the sign-in itself: it reads the 401, finds INITE Auth, registers and asks the person. The site needs no OAuth client of its own for this.

```ts
// lib/mcp.ts
import { createSiteMcp, protectedResource, jsonResult, textResult } from "@inite/mcp/site";
import { verifyAccessToken } from "@inite/auth";

const SITE = "https://www.example.com";
export const account = protectedResource({ site: SITE, path: "/mcp/account", name: "Example", documentation: `${SITE}/llms.txt` });

type Ctx = { reader: string | null };
export const mcp = createSiteMcp<Ctx>({
  name: "example",
  title: "Example",
  instructions: (ctx) => (ctx.reader ? "Signed in as the reader." : "Connect to /mcp/account to act for a reader."),
  tools: (ctx) => [
    {
      name: "search",
      description: "Search the site.",
      inputSchema: { type: "object", properties: { query: { type: "string" } }, required: ["query"] },
      annotations: { readOnlyHint: true },
      call: async ({ query }) => jsonResult({ results: await search(String(query)) }),
    },
  ],
});

// app/mcp/route.ts
export const { POST, GET, OPTIONS } = mcp.route({ context: () => ({ reader: null }) });

// app/mcp/account/route.ts
export const { POST, GET, OPTIONS } = mcp.route({
  resource: account,
  authenticate: (token, aud) => verifyAccessToken(token, { audience: aud }).catch(() => null),
  context: (_req, claims) => ({ reader: (claims as { sub: string }).sub }),
});

// app/.well-known/oauth-protected-resource/[[...path]]/route.ts
export const GET = protectedResourcesRoute([account]);

// app/.well-known/mcp.json/route.ts
export const GET = () => mcpCardResponse({ site: SITE, name: "example", title: "Example", description: "…",
  endpoints: [{ path: "/mcp" }, { path: "/mcp/account", resource: account }] });

// app/.well-known/mcp-registry-auth/route.ts  (to publish in the official MCP registry)
export const GET = () => mcpRegistryAuthResponse("<base64 ed25519 public key>");
```

A tool that throws becomes an error result the agent can read; the exception text stays in the log. `textResult(text, isError)` and `jsonResult(value)` build answers. For buying, pair it with `@inite/billing/purchases`: open a session, try `payFromWallet` for a signed-in reader, otherwise return `checkoutUrl` and `x402Url`.

Working examples: neuralcosmology.com (`/mcp`, `/mcp/account`), billing.inite.ai/mcp/wallet.

## Sub-paths

- `@inite/mcp/server` — `createMcpRoute`, `bridgeTools`, `FetchTransport`
- `@inite/mcp/site` — `createSiteMcp`, `protectedResource`, `protectedResourcesRoute`, `mcpCard`, `mcpRegistryAuthResponse`
- `@inite/mcp/apps` — `buildToolResult` for ADR-001 ext-apps responses
- `@inite/mcp/prompts` — `registerSkillsAsPrompts` (used by `@inite/skills`)

## Design constraints

- Stateless: one `McpServer` per request, no session state. Matches `inite-brain-service` pattern.
- Web `Request` / `Response` only — built for Next.js App Router route handlers, not Express.
- No domain knowledge. Tool permission map + auth callback come from the consumer.

## Related

- `ADR-003: MCP Server + Skills` — locked contract.
- `ADR-001: Composable UI Two-Path Envelope` — `buildToolResult` implements path 2 of this ADR.
- `@inite/assistant` — the tool registry this package bridges from.
