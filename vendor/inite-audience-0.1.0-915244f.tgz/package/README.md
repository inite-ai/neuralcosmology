# @inite/audience

The people a site writes to and hears from, on the site's own Postgres. No
runtime dependencies, no tenant, no Prisma models: the product hands in a
client (`fromPostgresJs(sql)`, `fromPrisma(prisma)`, or any `query(text, params)`).

```ts
const audience = createAudience({ sql: fromPostgresJs(sql), secret: process.env.AUDIENCE_SECRET!, unsubscribeUrl: (t) => `https://site/api/unsubscribe?t=${t}` })
```

Tables: run `AUDIENCE_SCHEMA` in the product's migration (additive).

| Need | Call |
|---|---|
| A form left an address | `askConsent({ email, purpose, wording })` → token for the letter |
| The person confirmed | `confirm(token)`, on POST: mail scanners open links |
| They said stop | `unsubscribe(token)` (accept POST for one-click), `withdraw(email)` |
| May I write? | `mayMail(email, purpose)` |
| Bounces, complaints | `readMailgunEvent(signingKey, body)` → `suppress(email, reason)` |
| A message from the site | `enquire({ email, kind, message })`, `enquiries()`, `setEnquiry()` |
| A letter to a segment | `recipients(segment)` to preview, `send(campaign, segment, write, transport)` |
| One person's data | `exportPerson(email)`, `erasePerson(email)` |

Rules: an absent field never erases a known one; a letter goes once per address
per campaign, and an address whose send was cut off is not retried; confirming
lifts the person's own unsubscribe, never a bounce, complaint or manual stop;
suppressions are kept as a keyed hash, so erasing a person does not make them
mailable. The secret must not change: links and suppressions depend on it.

Who may call these is the product's door: this package checks no session.
