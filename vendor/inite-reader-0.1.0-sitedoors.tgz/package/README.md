# @inite/reader

The online book reader the family's book sites share (mikefluff.com, neuralcosmology.com, nobody-quits.com): the reader's HTTP doors, its rules, its MCP tools and its interactive layer.

What it does:

- **Marks.** Bookmarks, highlights and notes. A note can be sent to the author by email, at most 30 a day.
- **Margin discussions.** Replies are one level deep. There are likes, and the author can hide, show, pin and delete.
- **Moderation that holds.** A comment the model turns down is kept `hidden`. The author sees it with Show and gets a letter; nothing is thrown away. The comment reaches the model inside `<comment>` tags, and only a reply that starts with REJECT rejects.
- **The AI companion.** It answers questions and explains passages, citing paragraphs (`[[anchor]]`). It knows the book only up to the chapter the reader is in, and only the chapters that reader may open. It also writes recaps of the earlier chapters, cached by each chapter's text.
- **Shared quotes.** A quote is accepted only if it appears in the chapter word for word. The link is short, and the same quote always gets the same link.
- **The reading place.** It syncs to the account. A chapter marked "read" never falls back to "reading".
- **MCP tools:**
  - `get_chapter_discussion`
  - `post_comment`
  - `send_note_to_author`
  - `get_author_inbox`
  - `moderate_comment`

## Wiring a site

```ts
// lib/reader.server.ts
import { createReader, anthropicReaderAi, type ReaderSite } from '@inite/reader'

const site: ReaderSite = {
  siteUrl: 'https://www.example.com',
  siteName: 'example.com',
  authorName: (lang) => (lang === 'ru' ? 'Михаил Савченко' : 'Mikhail Savchenko'),
  session: async (req) => /* the site's session → { sub, email, emailVerified, name, admin } */ null,
  chapter: async ({ book, lang, chapter }) => /* { title, index, hash, bookTitle } | null */ null,
  paragraphs: async (scope) => /* [anchor, text][], e.g. paragraphsFromHtml(html) */ null,
  chapters: async (book, lang) => /* [{ id, title, hash }] in order */ [],
  canRead: async (session, scope) => /* the site's own gate */ false,
  ownsBook: async (session, book) => false,
  isAuthor: (s) => s.admin || (s.emailVerified && s.email === 'author@example.com'),
  notify: (letter) => sendMailToAuthor(letter), // omit to turn notes to the author off
  ai: process.env.ANTHROPIC_API_KEY ? anthropicReaderAi({ apiKey: process.env.ANTHROPIC_API_KEY, model: 'claude-sonnet-5' }) : null,
}

export const reader = createReader(site, store /* a ReaderStore over the site's tables */)
```

```ts
// app/api/reader/state/route.ts
import { reader } from '@/lib/reader.server'
export const dynamic = 'force-dynamic'
export const { GET, PUT } = reader.routes.state
// annotations: POST PATCH DELETE · comments: GET POST · ai: POST · share: POST
// comments/[id]: export const POST = (req, { params }) => params.then(({ id }) => reader.routes.comment(req, id))
```

A place in a book is always `{ book, lang, chapter }`, where `lang` is the language of the text:

- A single-book site passes its one slug as `book`.
- A site that calls its chapters "parts" maps each part to a chapter.
- A chapter URL defaults to `/{lang}/read/{book}/{chapter}#a-{anchor}`. Override it with `site.chapterUrl`.
- A shared quote's URL defaults to `/{lang}/q/{id}`. Override it with `site.shareUrl`.

## The store

`ReaderStore` is one plain query per method; every rule lives in the package. `createMemoryStore()` is the reference implementation, and the package's tests run on it. Each site implements the store over its own tables (Prisma or SQL), whatever those tables are called. The columns it needs are:

| What | Columns |
|---|---|
| reading place | sub, book, lang → chapter, anchor, chapters (json), fraction?, updated_at |
| annotations | id, sub, book, lang, chapter, anchor, kind (bookmark/highlight/note), quote, start_off, end_off, color, note, sent_at, created_at |
| comments | id, book, lang, chapter, anchor, parent_id (cascade), sub, author_name, is_author, quote, body, status (published/hidden), pinned, created_at |
| reactions | comment_id (cascade), sub |
| shares | id (8 chars), book, lang, chapter, anchor, quote |
| AI usage / cache | sub, day → count · key → value |

A `rejected` status from older versions should become `hidden`, so the author sees those comments too.

## The interactive layer

```tsx
import { ReaderInteractive } from '@inite/reader/react'
import '@inite/reader/reader.css'

<ReaderInteractive book="…" lang="ru" chapter="ch01" locale="ru" bookTitle="…" author="Михаил Савченко"
  signedIn loginHref="/login" aiEnabled chapterIndex={0} prefix="mf" prose=".reader-prose" root="#reader" />
```

Set the theme on the reader's root: `--r-bg --r-panel --r-fg --r-soft --r-muted --r-line --r-faint --r-accent`. Optionally also `--rd-sans --rd-cap-font --rd-cap-size --rd-cap-weight --rd-cap-tracking --rd-cap-case --rd-title-font --rd-dock-offset --rd-radius`.

Marks inside the text keep the site's prefix, so their styles stay next to the site's prose:

- `.<prefix>-margin`: the margin button
- `.<prefix>-bm`: a bookmarked paragraph
- `.<prefix>-flash`: a paragraph after a jump
- `.<prefix>-focus`: focus mode, on the root or on `<html>`
- `--<prefix>-hl-<colour>`: the highlights
- `#<prefix>-recap-slot`: where the recap goes

The panels are portalled into the root: a site rule like `.reader.focus aside { display: none }` hides the package's drawer too (`<aside class="rd-panel">`); scope such rules to the site's own elements.

The words come in four languages (`MESSAGES`). Any of them can be overridden with `labels`.

Site-specific pieces plug in through props:

- `dockExtra`: a text size control, for example
- `progressExtra`: chapter statuses and how far in the reader is
- `colors`
- `quoteCard`
- `focusOn`
