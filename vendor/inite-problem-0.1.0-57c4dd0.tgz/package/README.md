# `@inite/problem`

RFC 9457 Problem Details: the family's one builder. It has no dependencies and runs on any runtime.

```ts
import { problemDetails, PROBLEM_CONTENT_TYPE } from "@inite/problem";
problemDetails({ status: 404, code: "not_found", detail: "No such habit", base: "https://break3.app/problems" });
// { type: "https://break3.app/problems/not_found", title: "Not found", status: 404, code: "not_found", detail: "No such habit" }
```

- **`type`:** `<base>/<code>` when the product documents its codes, else `about:blank`.
- **`title`:** stable per code. It defaults to the status text and is never the detail.
- **Owned members:** `type`, `title`, `status`, `detail`, `instance` and `code` are never replaced by extensions.
- **`problemInstance(req)`:** the request path only. The query string can carry a token or an e-mail address, so it is left out.

Layers on top of this package:

- **`@inite/api-kit`:** the family's kebab codes and titles, `error` as a string for older front ends, and `problem()` returning a NextResponse.
- **`@inite/mcp`:** puts the JSON-RPC error beside the problem (`refusal`) and returns tool errors as problems (`problemResult`).
- **Other services (NestJS backends):** build the body with `problemDetails()` instead of a local copy.
