# @inite/content

Blog (MDX + AEO), SEO metadata, JSON-LD, llms.txt, OG images, feeds and
sitemaps for the inite.* sites.

## For AI agents: `@inite/content/ai`

AI agents read sites, compare and buy for people. Three things make a site
easy for them.

**1. Every page as markdown.** The same text the reader sees, without the
layout. An agent appends `.md` to a page URL or sends
`Accept: text/markdown`; every HTML page announces its markdown version, and
the markdown points back to the HTML as canonical, so search engines still
see one page.

```ts
// middleware.ts
import { markdownRewrite, markdownAlternate } from '@inite/content/ai'

const target = markdownRewrite(pathname, request.headers.get('accept'), { skip: /\/transcript\.md$/ })
if (target) return NextResponse.rewrite(new URL(target, request.url))
// ...on the normal response:
response.headers.set('Link', markdownAlternate(pathname))
response.headers.set('Vary', 'Accept')
```

```ts
// app/md/[[...path]]/route.ts
import { markdownDoc, markdownResponse } from '@inite/content/ai'

export async function GET(_req: Request, { params }: { params: Promise<{ path?: string[] }> }) {
  const { path = [] } = await params
  const page = await findPage('/' + path.join('/'))          // the site's own lookup
  return markdownResponse(page && markdownDoc(page.title, page.url, [page.lead, page.body]))
}
```

**2. llms.txt that says how to use the site**, not only what it is:

```ts
import { llmsTxtResponse, agentsSection } from '@inite/content/ai'

export const GET = () =>
  llmsTxtResponse({
    sections: [
      agentsSection({
        site: 'https://www.example.com',
        catalog: '/catalog.json',
        mcp: { open: '/mcp', account: '/mcp/account', tools: ['search', 'read', 'buy'] },
        buying: { tool: 'buy', x402: true, wallet: true },
      }),
    ],
  })
```

It writes, in plain words: markdown is available; where the MCP server is;
how to connect for a person (their INITE sign-in); how to buy: a payment link
for the person, x402 for an agent with its own wallet, the person's INITE
wallet when they allowed it.

**3. An MCP server and payments.** See `@inite/mcp/site` (search, read, buy,
sign-in with INITE) and `@inite/billing/purchases` (checkout, x402, the INITE
wallet).

Working example: neuralcosmology.com (`/en/answers/<slug>.md`, `/llms.txt`,
`/mcp`).
