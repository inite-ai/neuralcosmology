# @inite/billing

The INITE billing service from a site's side: subscriptions, the price catalog
and one-time purchases. Billing keeps the money, the rails, the receipts and
the refunds; a site asks it for a checkout session and later asks whether the
order was paid.

## One-time purchases: `@inite/billing/purchases`

A buyer can pay a session three ways, and the site does almost nothing extra
for the last two:

1. **The payment page** (`checkoutUrl`): card, PIX, crypto, whatever billing's
   rails take.
2. **An AI agent with its own wallet** pays by x402 at `x402Url` (USDC on Base).
   Hand that URL to the agent next to the payment link. It is there only when
   billing can take x402.
3. **The buyer's INITE wallet.** If the buyer has allowed this site to charge
   their wallet, `payFromWallet` pays straight away. If not, billing returns
   one page on auth.inite.ai where they make a wallet if they have none, allow
   the site with limits (per payment, per month) using their passkey, top up
   if short, and pay this purchase. Next time no page is needed.

```ts
import { createBillingPurchases, checkoutUrlIn } from '@inite/billing/purchases'

export const billing = createBillingPurchases({
  url: process.env.BILLING_SERVICE_URL!,       // https://billing.inite.ai
  apiKey: process.env.BILLING_SERVICE_API_KEY!, // the site's service key
  site: 'mysite',                               // prefix for buyers without an account
  // walletPay: false,                          // never try the INITE wallet
})

// A buyer with an INITE account is their DID; without one, a hash of their email.
const userId = session?.userId ?? billing.guestUserId(email)

const s = await billing.createPurchase({
  priceCode: 'book-usd',
  userId,
  successUrl: 'https://mysite.com/thanks',
  errorUrl: 'https://mysite.com/book',
  locale: 'pt',                // billing's page and emails in the buyer's language
  idempotencyKey: requestId,
})

// Signed-in buyer (or an agent acting for one): try the wallet first.
const paid = session ? await billing.payFromWallet(s.sessionId, userId, { returnTo: pageUrl }) : null
if (paid?.status === 'paid') {
  // done, or `confirming` for a minute or two while Base makes it final
} else if (paid?.status === 'needs_approval') {
  redirect(paid.approveUrl) // `reason`: no_wallet | not_approved | over_limit | insufficient_funds
} else {
  redirect(checkoutUrlIn(s.checkoutUrl, locale)) // and give agents s.x402Url
}
```

`payFromWallet` never throws. Anything unexpected, including a billing that
does not offer it yet (404), comes back as `unavailable`, and the buyer pays
on the payment page. The approve link is accepted only on `https://*.inite.ai`.

Whether an order is paid is only ever what `getOrder(id)` says; nothing the
browser brings back counts.

Guest orders: when someone signs in with an email the identity provider has
verified, call `claimGuestPurchases(userId, email)` and the orders they made
as `guestUserId(email)` on this site move onto their account. Never with an
unverified email.

The module has no imports beyond `node:crypto`, so a site outside the pnpm
workspace can vendor the packed package (see mikefluff-site's
`scripts/sync-inite-auth.mjs` for the pattern).

Billing's side of all this: `docs/wallet.md` and `docs/x402.md` in
inite-billing-service; people-facing pages at billing.inite.ai/docs/wallet and
auth.inite.ai/docs/agents.
